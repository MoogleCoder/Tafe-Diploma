﻿namespace BeanSeans.Data
{
    public class Staff: Person
    {
        public override bool IsStaff

        {
            get { return true; }
        }
    }
}