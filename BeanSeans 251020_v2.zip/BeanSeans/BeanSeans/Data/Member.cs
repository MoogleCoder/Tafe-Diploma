﻿namespace BeanSeans.Data
{
    public class Member:Person
    {
        public override bool IsMember

        {
            get { return true; }
        }
    }
}