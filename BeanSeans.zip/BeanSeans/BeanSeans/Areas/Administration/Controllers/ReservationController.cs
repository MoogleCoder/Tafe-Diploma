﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using BeanSeans.Data;
using Microsoft.AspNetCore.Identity;

namespace BeanSeans.Areas.Administration
{
    [Area("Administration")]
    public class ReservationController : AdministrationAreaController
    {

        public ReservationController(SignInManager<IdentityUser> sim, UserManager<IdentityUser> um, ApplicationDbContext _db) : base(sim, um, _db)
        {

        }

        // GET: Administration/Reservation
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _db.Reservations.Include(r => r.Person)
                                                       .Include(r => r.Sitting)
                                                        .Include(r => r.Source)
                                                        .Include(r => r.Status);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: Administration/Reservation/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reservation = await _db.Reservations
                .Include(r => r.Person)
                .Include(r => r.Sitting)
                .Include(r => r.Source)
                .Include(r => r.Status)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (reservation == null)
            {
                return NotFound();
            }

            return View(reservation);
        }

        // GET: Administration/Reservation/Create
        public IActionResult Create()
        {
            ViewData["PersonId"] = new SelectList(_db.People, "Id", "Discriminator");
            ViewData["SittingId"] = new SelectList(_db.Sittings, "Id", "Id");
            ViewData["SourceId"] = new SelectList(_db.ReservationSources, "Id", "Id");
            ViewData["StatusId"] = new SelectList(_db.ReservationStatuses, "Id", "Id");
            return View();
        }

        // POST: Administration/Reservation/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("PersonId,SittingId,StatusId,SourceId,Id,Guest,StartTime,Duration,Note")] Reservation reservation)
        {
            if (ModelState.IsValid)
            {
                _db.Add(reservation);
                await _db.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["PersonId"] = new SelectList(_db.People, "Id", "Discriminator", reservation.PersonId);
            ViewData["SittingId"] = new SelectList(_db.Sittings, "Id", "Id", reservation.SittingId);
            ViewData["SourceId"] = new SelectList(_db.ReservationSources, "Id", "Id", reservation.SourceId);
            ViewData["StatusId"] = new SelectList(_db.ReservationStatuses, "Id", "Id", reservation.StatusId);
            return View(reservation);
        }

        // GET: Administration/Reservation/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reservation = await _db.Reservations.FindAsync(id);
            if (reservation == null)
            {
                return NotFound();
            }
            ViewData["PersonId"] = new SelectList(_db.People, "Id", "Discriminator", reservation.PersonId);
            ViewData["SittingId"] = new SelectList(_db.Sittings, "Id", "Id", reservation.SittingId);
            ViewData["SourceId"] = new SelectList(_db.ReservationSources, "Id", "Id", reservation.SourceId);
            ViewData["StatusId"] = new SelectList(_db.ReservationStatuses, "Id", "Id", reservation.StatusId);
            return View(reservation);
        }

        // POST: Administration/Reservation/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PersonId,SittingId,StatusId,SourceId,Id,Guest,StartTime,Duration,Note")] Reservation reservation)
        {
            if (id != reservation.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _db.Update(reservation);
                    await _db.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ReservationExists(reservation.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["PersonId"] = new SelectList(_db.People, "Id", "Discriminator", reservation.PersonId);
            ViewData["SittingId"] = new SelectList(_db.Sittings, "Id", "Id", reservation.SittingId);
            ViewData["SourceId"] = new SelectList(_db.ReservationSources, "Id", "Id", reservation.SourceId);
            ViewData["StatusId"] = new SelectList(_db.ReservationStatuses, "Id", "Id", reservation.StatusId);
            return View(reservation);
        }

        // GET: Administration/Reservation/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reservation = await _db.Reservations
                .Include(r => r.Person)
                .Include(r => r.Sitting)
                .Include(r => r.Source)
                .Include(r => r.Status)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (reservation == null)
            {
                return NotFound();
            }

            return View(reservation);
        }

        // POST: Administration/Reservation/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var reservation = await _db.Reservations.FindAsync(id);
            _db.Reservations.Remove(reservation);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ReservationExists(int id)
        {
            return _db.Reservations.Any(e => e.Id == id);
        }
    }
}
