﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ReservationSystemPrototype.Data
{
    public class Table
    {
        public Table()
        {
            ReservationTables = new List<ReservationTable>();
        }
        [Required]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public Area Area { get; set; }
        [Required]
        public int AreaId { get; set; }

        public List<ReservationTable> ReservationTables { get; set; }
    }
}
