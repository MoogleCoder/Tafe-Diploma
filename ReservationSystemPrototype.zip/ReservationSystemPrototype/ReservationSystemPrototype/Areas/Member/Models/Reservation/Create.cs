﻿using ReservationSystemPrototype.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ReservationSystemPrototype.Areas.Member.Models
{
    public class Create
    {
        public Sitting Sitting { get; set; }

        public DateTime Time { get; set; }

        public Person Person { get; set; }

        public int Guests { get; set; }

    }
}
