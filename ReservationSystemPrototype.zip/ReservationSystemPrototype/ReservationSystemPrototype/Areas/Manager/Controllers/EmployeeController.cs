﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ReservationSystemPrototype.Areas.Manager.Models.Employee;
using ReservationSystemPrototype.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace ReservationSystemPrototype.Areas.Manager.Controllers
{
    [Area("Manager")]
    public class EmployeeController : ManagerAreaController
    {
        public EmployeeController(SignInManager<IdentityUser> sim,UserManager<IdentityUser> um, ApplicationDbContext db) 
            : base(sim,um, db) { }

        public IActionResult Index()
        {
            var employees = _db.Employees.ToArray(); 
            return View();
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View(); 
        }
        [HttpPost]
        public async Task<IActionResult> Create(Models.Employee.Create m)
        {
            var user = new IdentityUser { UserName = m.Email, Email = m.Email };
            var result = await _userManager.CreateAsync(user, m.Password);
            if(result.Succeeded)
            {
                await _userManager.AddToRoleAsync(user, "Manager"); 

                var employee = new Employee
                {
                    FirstName = m.FirstName,
                    LastName = m.LastName,
                    UserId = user.Id
                };

                _db.Employees.Add(employee);
                await _db.SaveChangesAsync();
                return RedirectToAction("Index"); 
      

            }
            return View(m);
        }
    }
}