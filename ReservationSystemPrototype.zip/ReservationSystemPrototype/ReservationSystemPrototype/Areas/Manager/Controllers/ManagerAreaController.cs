﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ReservationSystemPrototype.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace ReservationSystemPrototype.Areas.Manager.Controllers
{
    [Area("Manager")]
    [Authorize(Roles = "Manager")]
    public class ManagerAreaController : Controller
    {
        protected readonly SignInManager<IdentityUser> _signInManager;
        protected readonly UserManager<IdentityUser> _userManager;
        protected readonly ApplicationDbContext _db;
        private SignInManager<IdentityUser> sim;
        private ApplicationDbContext db;

        public ManagerAreaController(SignInManager<IdentityUser> sim, ApplicationDbContext db)
        {
            this.sim = sim;
            this.db = db;
        }

        public ManagerAreaController(SignInManager<IdentityUser> sim,UserManager<IdentityUser> um, ApplicationDbContext db)
        {
            _signInManager = sim; 
            _userManager = um;   
            _db = db;
        }

    }
}