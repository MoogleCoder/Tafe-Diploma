﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ReservationSystemPrototype.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ReservationSystemPrototype.Areas.Manager.Controllers
{
    [Area("Manager")]
    public class ReservationController : ManagerAreaController
    {
        public ReservationController(SignInManager<IdentityUser> sim, ApplicationDbContext db) : base(sim, db) { }

        public async Task<IActionResult> Index()
        {
            var u = await _userManager.FindByEmailAsync(User.Identity.Name);
            var m = await _db.Members.FirstOrDefaultAsync(m => m.UserId == u.Id);
            var Reservations = _db.Reservations
                                    .Include(r => r.Status)
                                    .Where(r => r.PersonId == m.Id);
            return View(Reservations);
        }
        // GET: Manager/Sittings/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var sitting = await _db.Sittings
                .FirstOrDefaultAsync(m => m.Id == id);
            if (sitting == null)
            {
                return NotFound();
            }

            return View(sitting);
        }

        // GET: Manager/Sittings/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Manager/Sittings/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Start,End,Name,Capacity")] Sitting sitting)
        {
            if (ModelState.IsValid)
            {
                sitting.RestaurantId = 1;
                _db.Add(sitting);
                await _db.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(sitting);
        }

        // GET: Manager/Sittings/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var sitting = await _db.Sittings.FindAsync(id);
            if (sitting == null)
            {
                return NotFound();
            }
            return View(sitting);
        }

        // POST: Manager/Sittings/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Start,End,Name,Capacity")] Reservation Reservation)
        {
            if (id != Reservation.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _db.Update(Reservation);
                    await _db.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ReservationExists(Reservation.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(Reservation);
        }

        // GET: Manager/Sittings/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var sitting = await _db.Sittings
                .FirstOrDefaultAsync(m => m.Id == id);
            if (sitting == null)
            {
                return NotFound();
            }

            return View(sitting);
        }

        // POST: Manager/Sittings/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var sitting = await _db.Sittings.FindAsync(id);
            _db.Sittings.Remove(sitting);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ReservationExists(int id)
        {
            return _db.Sittings.Any(e => e.Id == id);
        }
    }
}
