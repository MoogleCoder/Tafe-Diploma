﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ReservationSystemPrototype.Data
{
    public class Restaurant
    {

        public Restaurant()
        {
            Sittings = new List<Sitting>(); 
        }
        public int Id { get; set; }

        public string Name { get; set; }

        public List<Sitting> Sittings { get; set; }
    }
}
