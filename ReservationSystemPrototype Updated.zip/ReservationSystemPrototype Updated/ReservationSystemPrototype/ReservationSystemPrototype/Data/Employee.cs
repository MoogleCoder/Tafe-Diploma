﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ReservationSystemPrototype.Data
{
    public class Employee : Person
    {

        public override bool IsEmployee
        {
            get
            {
                return true;
            }
        }
    }
}
