﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ReservationSystemPrototype.Data
{
    public class SittingType
    {

        [Required]
        public int Id { get; set; }
        [Required]
        public string Description { get; set; }
        [Required]
        public List<Sitting> Sittings { get; set; }

        public SittingType()
        {
            Sittings = new List<Sitting>();
        }
    }
}
