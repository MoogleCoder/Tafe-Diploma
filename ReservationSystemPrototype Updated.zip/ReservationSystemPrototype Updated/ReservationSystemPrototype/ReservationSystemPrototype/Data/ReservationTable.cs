﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ReservationSystemPrototype.Data
{
    public class ReservationTable
    {
        
        [Key]
        public int Id { get; set; }
      
        public int TableId { get; set; }
       
        public Table Table { get; set; }
       
        public int ReservationId { get; set; }
       
        public Reservation Reservation { get; set; }
    }
}

