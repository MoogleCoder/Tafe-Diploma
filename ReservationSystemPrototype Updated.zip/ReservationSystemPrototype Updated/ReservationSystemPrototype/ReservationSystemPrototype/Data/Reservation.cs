﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ReservationSystemPrototype.Data
{
    public class Reservation
    {
        public int Id { get; set; }
        public int PersonId { get; set; }
        public Person Person { get; set; }

        public int SittingId { get; set; }
        public Sitting Sitting { get; set; }

        public bool IsMember
        {
            get
            {
                return Person.IsMember; 
            }
        }
        public DateTime StartTime { get; set; }

        public int Guests { get; set; }

        public int StatusId { get; set; }
        public ReservationStatus Status { get; set; }
    }
}
