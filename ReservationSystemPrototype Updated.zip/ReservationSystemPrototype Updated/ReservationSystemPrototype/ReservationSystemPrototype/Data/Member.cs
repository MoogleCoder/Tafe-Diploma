﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ReservationSystemPrototype.Data
{
    public class Member : Person
    {

        public override bool IsMember
        {
            get
            {
                return true;
            }
        }
        
    }
}
