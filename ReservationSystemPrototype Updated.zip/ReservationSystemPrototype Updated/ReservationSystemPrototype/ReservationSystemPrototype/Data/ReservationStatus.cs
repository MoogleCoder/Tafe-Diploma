﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ReservationSystemPrototype.Data
{
    public class ReservationStatus
    {

        [Required]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }

        public List<Reservation> Reservations { get; set; }

        public ReservationStatus()
        {
            Reservations = new List<Reservation>();
        }
    }
}
