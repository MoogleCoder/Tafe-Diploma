﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ReservationSystemPrototype.Areas.Staff.Models;
using ReservationSystemPrototype.Data;

namespace ReservationSystemPrototype.Controllers
{
    public class ReservationController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        private readonly UserManager<IdentityUser> _userManager;
        private readonly ApplicationDbContext _db;

        public ReservationController(UserManager<IdentityUser> userManager, ApplicationDbContext db)
        {
            _userManager = userManager;
            _db = db;

        }
        public IActionResult Sittings()
        {
            return View(_db.Sittings.ToList());
        }

        [HttpGet] //id = selected sitting id
        public async Task<IActionResult> Create(int id)
        {
            var sitting = _db.Sittings.FirstOrDefault(s => s.Id == id);
            if (sitting == null)
            {
                return NotFound();
            }
            var m = new Create
            {
                Sitting = sitting,
                Time = sitting.Start
            };

            if (User.Identity.IsAuthenticated && User.IsInRole("Member"))
            {
                var user = await _userManager.FindByNameAsync(User.Identity.Name);
                m.Person = await _db.Members.FirstOrDefaultAsync(m => m.UserId == user.Id);
            }
            return View(m);
        }

        [HttpPost]
        public async Task<IActionResult> Create(Create m)
        {
            var sitting = _db.Sittings.FirstOrDefault(s => s.Id == m.Sitting.Id);
            if (sitting == null)
            {
                return NotFound();
            }
            if (m.Time < sitting.Start || m.Time > sitting.End)
            {
                ModelState.AddModelError("Time", "Invalid Time, must fall within sitting start/end times");
            }
            if (ModelState.IsValid)
            {
                bool isMember = false;
                Person p;
                if (User.Identity.IsAuthenticated && User.IsInRole("Member"))
                {
                    var user = await _userManager.FindByNameAsync(User.Identity.Name);
                    p = await _db.Members.FirstOrDefaultAsync(m => m.UserId == user.Id);
                    isMember = true;
                }
                else
                {
                    p = new Person
                    {
                        FirstName = m.Person.FirstName,
                        LastName = m.Person.LastName
                    };
                    _db.People.Add(p);
                }

                var r = new Reservation
                {
                    Guests = m.Guests,
                    StartTime = m.Time,
                    SittingId = sitting.Id,
                    StatusId = 1
                };

                p.Reservations.Add(r);
                _db.SaveChanges();

                if (isMember)
                {
                    return RedirectToAction("Index", "Reservation", new { Area = "Member" });
                }

                return RedirectToAction(nameof(Details), new { id = r.Id });
            }
            //if we got this far then the model was not valid so send back create form
            //with validation errors
            m.Sitting = sitting;
            return View(m);
        }

        //id is Reservation id
        public IActionResult Details(int id)
        {
            var Reservation = _db.Reservations
                                    .Include(r => r.Person)
                                    .Include(r => r.Sitting)
                                    .Include(r => r.Status)
                                    .FirstOrDefault(r => r.Id == id);
            if (Reservation == null)
            {
                return NotFound();
            }

            return View(Reservation);

        }
    }
}
