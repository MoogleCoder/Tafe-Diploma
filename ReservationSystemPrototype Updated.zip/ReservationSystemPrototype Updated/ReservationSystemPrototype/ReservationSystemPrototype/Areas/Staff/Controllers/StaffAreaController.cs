﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ReservationSystemPrototype.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace ReservationSystemPrototype.Areas.Staff.Controllers
{
    [Area("Staff")]
    [Authorize(Roles = "Staff")]
    public class StaffAreaController : Controller
    {
        protected readonly SignInManager<IdentityUser> _signInManager;
        protected readonly UserManager<IdentityUser> _userManager;
        protected readonly ApplicationDbContext _db;
        private UserManager<IdentityUser> um;
        private ApplicationDbContext db;

        public StaffAreaController(UserManager<IdentityUser> um, ApplicationDbContext db)
        {
            this.um = um;
            this.db = db;
        }

        public StaffAreaController(SignInManager<IdentityUser> sim,UserManager<IdentityUser> um, ApplicationDbContext db)
        {
            _signInManager = sim; 
            _userManager = um;   
            _db = db;
        }

    }
}