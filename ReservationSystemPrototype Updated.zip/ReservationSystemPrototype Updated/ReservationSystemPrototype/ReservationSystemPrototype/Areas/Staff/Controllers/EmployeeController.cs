﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ReservationSystemPrototype.Areas.Staff.Models.Employee;
using ReservationSystemPrototype.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using ReservationSystemPrototype.Areas.Staff.Controllers;
using Microsoft.AspNetCore.Authorization;

namespace ReservationSystemPrototype.Areas.Staff.Controllers
{
    [Area("Staff")]
    [Authorize(Roles = "Staff")]

    public class EmployeeController : StaffAreaController
    {
        public EmployeeController(SignInManager<IdentityUser> sim,UserManager<IdentityUser> um, ApplicationDbContext db) 
            : base(sim,um, db) { }


        public IActionResult Index()
        {
            var employees = _db.Employees.ToArray(); 
            return View(employees);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View(); 
        }
        [HttpPost]
        public async Task<IActionResult> Create(Models.Employee.Create m)
        {
            var user = new IdentityUser { UserName = m.Email, Email = m.Email };
            var result = await _userManager.CreateAsync(user, m.Password);
            if(result.Succeeded)
            {
                await _userManager.AddToRoleAsync(user, "Staff"); 

                var employee = new Employee
                {
                    FirstName = m.FirstName,
                    LastName = m.LastName,
                    UserId = user.Id
                };

                _db.Employees.Add(employee);
                await _db.SaveChangesAsync();
                return RedirectToAction("Index"); 
      

            }
            return View(m);
        }

        [HttpGet]
        [Authorize(Roles = "Manager")]
        public async Task<IActionResult> Managers()
        {
            var m = new List<Models.Employee.ManagerVM>();
            foreach(var e in _db.Employees.ToArray())
            {
                var u = await _userManager.FindByNameAsync(e.UserId);
                var roles =  await _userManager.GetRolesAsync(u);
                m.Add(new ManagerVM { User = u, Roles = roles});
            }
            return View(m);
        }
    }
}