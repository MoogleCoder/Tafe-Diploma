﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ReservationSystemPrototype.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ReservationSystemPrototype.Areas.Member.Controllers
{
   [Area("Member")]
    public class ReservationController : MemberAreaController
    {
        public ReservationController(UserManager<IdentityUser> um,ApplicationDbContext db) :base(um,db) {}

        public async Task<IActionResult> Index()
        {
            var u = await _userManager.FindByEmailAsync(User.Identity.Name);
            var m = await _db.Members.FirstOrDefaultAsync(m => m.UserId == u.Id);
            var Reservations = _db.Reservations
                                    .Include(r => r.Status)
                                    .Where(r => r.PersonId == m.Id); 
            return View(Reservations);
        }
    }
}